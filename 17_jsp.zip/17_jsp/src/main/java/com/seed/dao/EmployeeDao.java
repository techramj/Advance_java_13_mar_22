package com.seed.dao;

import java.sql.Connection;

import com.seed.Employee;

public class EmployeeDao {
	
	private Connection connection;
	
	public void addEmployee(Employee emp){
		
	}

}
