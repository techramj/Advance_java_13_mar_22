package com.zensar.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogoutServlet extends HttpServlet{
	
	@Override
	public void init() throws ServletException {
		System.out.println("init method");
		ServletConfig servletConfig = getServletConfig();
		String driver = servletConfig.getInitParameter("jdbc.oracle.drivername");
		String url = servletConfig.getInitParameter("jdbc.oracle.url");
		System.out.println("Driver: "+driver);
		System.out.println("Url: "+url);
		
		ServletContext context = getServletContext();
		String username=context.getInitParameter("oracle.username");
		String password= context.getInitParameter("oracle.password");
		System.out.println("oracle username: "+username);
		System.out.println("orcle password: "+password);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("get method called");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("post methode called");
	}

}
