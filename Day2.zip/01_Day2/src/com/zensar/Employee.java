package com.zensar;

public class Employee {

	private int id;
	private String name;
	private double salary;
	private static String companyName = "Zensar";

	public Employee() {
		super();
	}

	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public static String getCompanyName() {
		return companyName;
	}
	
	@Override
	public String toString() {
		return "Id: "+id+"\nName:"+name+"\nSalary:"+salary+"\n";
	}
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("See you soon!!!!!");
	}
	
	public double computeSalary() {
		//System.out.println("employee computesalary");
		return salary;
	}
	
	public void disp() {
		System.out.println(this.getClass().getName());
	}
	

}
