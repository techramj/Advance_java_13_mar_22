package com.zensar;

import java.util.Arrays;
import java.util.Comparator;

public class Test {

	public static void main(String[] args) {
		expDynamicBinding();
	}

	public static void expDynamicBinding() {
		Employee jack = new Employee(1, "jack", 5000);
		Manager john = new Manager(2, "John", 9000, 2);

		Employee e1 = new Manager(3, "Jessica", 9000, 2);
		
		Employee e2 = new SalesPerson(10, "Jassi", 5000, 10000, 1);
	
		// Manager m1 = jack; //subclass cannot refer to super class

		// binding
		System.out.println(jack.computeSalary());
		System.out.println(john.computeSalary());
		System.out.println(e1.computeSalary());

		double bonus = john.calculateBonus();
		double bonus1 = ((Manager) e1).calculateBonus();
		
		System.out.println("---------------------");
		displayEmpDetails(jack);
		displayEmpDetails(john);
		displayEmpDetails(e1);
		displayEmpDetails(e2);

		// compiler will check static binding
		// execution will be have dynamic binding
	}

	public static void displayEmpDetails(Employee emp) {
		System.out.println(emp.getClass().getName());
		System.out.println(emp);
		System.out.println("Net salary: "+emp.computeSalary());
		if(emp instanceof Manager) {
			System.out.println("Bonus: "+((Manager)emp).computeSalary());
		}
		if(emp instanceof SalesPerson) {
			System.out.println("Commission: "+((SalesPerson)emp).getCommission());
		}
		System.out.println("=================================================");
	}
	
	public static void exp2() {
		Employee jack = new Employee(1, "jack", 5000);
		Manager john = new Manager(2, "John", 9000, 2);

		System.out.println(jack instanceof Employee);
		System.out.println(jack instanceof Manager);

		System.out.println(john instanceof Employee);
		System.out.println(john instanceof Manager);

		System.out.println(john instanceof Object);
		System.out.println(jack instanceof Object);

	}

	public static void exp1() {
		Employee jack = new Employee(1, "jack", 5000);

		Manager john = new Manager(2, "John", 9000, 2);

		System.out.println(jack.getClass().getName());
		System.out.println(jack.hashCode());
		String hex = Integer.toHexString(jack.hashCode());
		System.out.println(hex);
		System.out.println(jack);

		System.out.println(john);
	}

	public static void gcExp1() {
		int a = 10;
		Employee emp1;
		emp1 = new Employee(1, "jack", 5000);
		Employee emp2 = new Employee(2, "john", 5000);

		emp1 = emp2;
		emp1 = null;
		emp2 = null;
		System.gc();

		System.out.println("End");

	}

	public static void gcExp2() {
		Employee e;
		for (int i = 0; i < 999999; i++) {
			e = new Employee();
		}
		System.out.println("end");

	}

	public static void exp3() {
		Employee[] empArr = new Employee[5];
		for (int i = 0; i < empArr.length; i++) {
			empArr[i] = new Employee(i, "name" + i, i * 1000);
		}
		empArr[2].setName("Jack");
		empArr[2].setName("Prachi");
		empArr[4].setName("Garima");

		displayEmployees(empArr);
		System.out.println("sorting by name");
		sortByName(empArr);
		displayEmployees(empArr);

	}

	public static void displayEmployees(Employee[] arr) {
		for (Employee e : arr) {
			System.out.println(e);
		}
	}

	public static double avgSalary(Employee[] arr) {
		double totalSal = 0;
		for (Employee e : arr) {
			totalSal = totalSal + e.getSalary();
		}
		return totalSal / arr.length;
	}

	public static void sortByName(Employee[] arr) {
		Arrays.sort(arr, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
	}

// wap array if emp. Atleast add 3 employees and sort it by salary
//method to display the details of emp array
//method to sort the emp array 

}
