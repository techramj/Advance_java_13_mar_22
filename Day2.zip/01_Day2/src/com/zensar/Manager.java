package com.zensar;

public class Manager extends  Employee{
	
	private int noOfSuboridante;
	
	public Manager() {
		super();
	}

	public Manager(int id, String name, double salary, int noOfSuboridante) {
		super(id, name, salary);
		this.noOfSuboridante = noOfSuboridante;
	}
	
	@Override
	public String toString() {
		return super.toString()+"No Of suboridnate: "+noOfSuboridante+"\n";
	}
	
	
	public double calculateBonus() {
		return noOfSuboridante *200;
	}
	
	@Override
	public double computeSalary() {
		//System.out.println("manager conputesalary");
		return getSalary()+ calculateBonus();
	}

}
