package com.zensar;

public class Student {
	
	private int rollNumber;
	private String name;
	

}
