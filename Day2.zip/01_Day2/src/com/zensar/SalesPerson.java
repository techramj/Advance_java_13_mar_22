package com.zensar;

public class SalesPerson extends Employee{
	private double sales;
	private double comm;
	
	public SalesPerson() {
		// TODO Auto-generated constructor stub
	}

	public SalesPerson(int id, String name, double salary,  double sales,double comm) {
		super(id, name, salary);
		this.sales = sales;
		this.comm = comm;
	}
	
	public double getCommission(){
		return sales*comm/100;
	}
	
	
	@Override
	public double computeSalary() {
		// TODO Auto-generated method stub
		return super.computeSalary()+getCommission();
	}
	
}
