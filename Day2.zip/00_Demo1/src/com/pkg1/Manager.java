package com.pkg1;

import com.zensar.Employee;

public class Manager extends Employee {
	
	private int noOfSubordinate;
	
	public Manager() {
		System.out.println("Default Manager consructor");
	}
	
	public Manager(int id,String name, double salary, int subOrdiante) {
		super(id, name, salary);
		this.noOfSubordinate = subOrdiante;
		a = 222;
	}
	
	
	@Override
	public double computeSalary() {
		return super.computeSalary() + noOfSubordinate*200;
	}
	
	
	public void foo(int x) {}
	

}
