package com.pkg2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import com.pkg1.Manager;
import com.zensar.Employee;

public class Main {
	
	public static void main(String[] args) {
		Employee e  = new Employee();
		Manager m = new Manager();
		try {
			readFile1("E:\\test\\a.txt");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	
	public static void readFile(String filename) throws Exception {
		FileInputStream fis = new FileInputStream(filename);
		int x=fis.read();
		while(x!=-1) {
			System.out.print((char)x);
			x =fis.read();
			Thread.sleep(10);
		}
		
	}
	
	
	public static void readFile1(String filename) throws Exception {
		FileInputStream fis = new FileInputStream(filename);
		FileReader fr = new FileReader(filename);
		BufferedReader br = new BufferedReader(fr);
		
		String  line=br.readLine();
		while(line != null) {
			System.out.println(line);
			line = br.readLine();
			Thread.sleep(10);
		}
		
	}

}
