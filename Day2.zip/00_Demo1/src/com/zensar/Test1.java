package com.zensar;

import java.util.Scanner;

import com.pkg1.Manager;

public class Test1 {

	public static void main(String[] args) {
		//Employee e=new Employee();
		
		Manager manager = new Manager();
	    manager.a =20;
	    Employee  e =  new Employee();
	    e.a =1234;
		
	}
	
	public static void printDiamondPattern() {
		int a=65;
		for(int i=1;i<=9;i++) {
			int k= Math.abs(5-i);
			
			//print space
			for(int j=1;j<=k;j++) {
				System.out.print(" ");
			}
			
			int l = 5-k;
			//print star
			for(int j=1;j<=2*l-1;j++) {
				System.out.print((char)a);
				a++;
				if(a>90) {
					a=65;
				}
			}
			System.out.println();
			
		}
	}
	
	public static void printGrade(int mark) {
		String grade;
		if (mark >= 80 ) {
			grade ="A";
			//System.out.println("Grade => A");
		} else if (mark >= 60 ) {
			grade ="B";
			System.out.println("Grade: B");
		} else if (mark >= 40 ) {
			grade ="C";
			//System.out.println("Grade: C");
		} else {
			grade ="FAIL";
			//System.out.println("Grade: FAIL");
		}
		
		System.out.println("Grade=> "+grade);

	}
	
	public static int sumOfDigit(int x) {
		if(x<=10) {
			return x;
		}
		return x%10 + sumOfDigit(x/10);
	}

}
