package com.zensar;

public class Employee {

	private int id;
	private String name;
	private double salary;
	private double hra;
	
	protected int a =1111;
	int b =2222;

	public Employee() {
		System.out.println("Emp default constructor");
	}

	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.hra = .4 * salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
		this.hra = .4 *salary;
	}

	public double getHra() {
		return hra;
	}

	public void setHra(double hra) {
		this.hra = hra;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", hra=" + hra + "]";
	}

	public double computeSalary() {
		return salary + hra;
	}
	
	public void foo() {}

}
