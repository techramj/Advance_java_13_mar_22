import java.math.BigDecimal;
import java.math.BigInteger;

public class WrapperClassDemo {
	
	public static void main(String[] args) {
		int a=10;
		Integer iob1 = new Integer(10);
		Integer iob2 = Integer.valueOf(10);
		
		Integer iob3 = 10;  //autoboxing
		
		int x = iob1.intValue();
		x = iob2;  //unboxing
		
		System.out.println(Integer.SIZE);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.BYTES);
		System.out.println(Integer.toBinaryString(iob1));
		System.out.println(Integer.toHexString(x));
		System.out.println(Integer.toOctalString(x));
		
		int y = Integer.parseInt("10");
		
		Integer iob4 = iob1 + iob2;
		
		double d1= 10.00001;
		double d2 = 3.14;
		double d3 = 2 * d2 * d1;
		System.out.println(d3);
		
		BigDecimal bd1 = BigDecimal.valueOf(10.00001);
		BigDecimal bd2 = BigDecimal.valueOf(3.14);
		BigDecimal bd3 = bd1.multiply(bd2).multiply(BigDecimal.valueOf(2.0));
		System.out.println(bd3);
		
		System.out.println(reverseString("abcdefghijk"));
		System.out.println(isPallindrome("malayalam"));
		System.out.println(isPallindrome("abcde"));
		System.out.println(isPallindrome("nitin"));
				
	}
	
	public static String reverseString(String str) {
		return  new StringBuilder(str).reverse().toString();
	}	
	
	public static boolean isPallindrome(String str) {
		return str.equals(reverseString(str));
	}
	
	

}
