import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationDemo {
	
	public static void main(String[] args) {
		String filename="E:\\test\\emp.dat";
		Address add = new Address("Pune",411028);
		Employee emp = new Employee(1, "jack", 4000, add);
		//writeObject(filename, emp);
		
		Employee emp1 =readObject(filename);
		System.out.println(emp1);
		
		
		//array of emp 
		//write and read
	}
	
	public static void writeObject(String filename, Employee emp) {
		try(FileOutputStream fos= new FileOutputStream(filename);
				ObjectOutputStream oos = new ObjectOutputStream(fos); ){
			 oos.writeObject(emp);
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("object stored in file");
	}
	
	public static Employee readObject(String filename) {
		Employee emp = null;
		try(FileInputStream fis = new FileInputStream(filename);
				ObjectInputStream ois = new ObjectInputStream(fis)){
			emp=(Employee) ois.readObject();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return emp;
	}

}
