
public class CloningDemo {
	
	public static void main(String[] args) throws CloneNotSupportedException {
		exp2();
	}
	
	public static void exp2() throws CloneNotSupportedException {
		Address add = new Address("Pune",411028);
		Employee emp = new Employee(1, "jack", 4000, add);
		Employee emp1 = emp.clone();
		emp.setName("Jessica");
		emp.getAddress().setPincode(123);
		
		System.out.println(emp);
		System.out.println(emp1);
		
		System.out.println(emp.getAddress() == emp1.getAddress());
	}
	
	public static void exp1() throws CloneNotSupportedException {
		MyDate dob1 = new MyDate(2, 2, 2002);
		MyDate dob2 = dob1;
		
		MyDate dob3 = dob1.clone();
		System.out.println(dob1);
		System.out.println(dob3);
		
		
		System.out.println(dob1 == dob3);
		System.out.println(dob1.equals(dob3));
	}
	
	

}
