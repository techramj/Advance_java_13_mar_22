package com.zensar.before;

import java.util.ArrayList;
import java.util.List;

public class BeforeJava5CollectionDemo {
	public static void main(String[] args) {
		List list = new ArrayList();
		list.add(10);
		list.add(10.5);
		list.add(new BeforeJava5CollectionDemo());
		list.add("sample");
		
		List intList = new ArrayList();
;	}
}
