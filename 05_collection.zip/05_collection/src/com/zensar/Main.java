package com.zensar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Main {
	public static void main(String[] args) {
		// generalDemo();
		// genericDemo();
		//genericDemo1();
		hashMapDemo1();
		
		displayNoOFLetter("This is the demo for the hash map");

	    
	    //the same order in which character appeared
	    //the sorted order a letter
	    //ignore the case and display in sorted order.

	}
	
	public static void displayNoOFLetter(String str) {
		char[] arr = str.toLowerCase().toCharArray();
		Map<Character, Integer> map = new TreeMap<Character, Integer>();
		for(char ch:arr) {
			Integer count=map.put(ch, 1);
			if(count != null) {
				map.put(ch, count+1);
			}
		}
		System.out.println(map);
	}
	
	public static void hashMapDemo1() {
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("Pune", 13456788L);
		map.put("Mumbai", 23456788L);
		map.put("Nagpur", 11456788L);
		Long x= map.put("Kanpur", 1111L);
		System.out.println(x);
		x= map.put("Kanpur", 2222L);
		System.out.println(x);
		//System.out.println(map);
		display1(map);
	}
	

	
	public static void display1(Map<String,Long> map) {
		Set<Entry<String, Long>> entrySet = map.entrySet();
		
		for(Entry<String, Long> entry:entrySet) {
			System.out.println(entry.getKey()+"  "+entry.getValue());
		}
	}
	
	public static void display(Map<String,Long> map) {
		Set<String> keySet = map.keySet();
		System.out.println(keySet);
		for(String key:keySet) {
			System.out.println(key+"  "+map.get(key));
		}
	}
	
	public static void hashSetDemo2() {
		Set<Integer> iSet = new HashSet<Integer>();
		iSet.add(10);
		iSet.add(5);
		iSet.add(5);
		iSet.add(8);
		iSet.add(101);
		iSet.add(50);
		iSet.add(80);
		iSet.add(80);
		System.out.println(iSet.size());
		System.out.println(iSet);
		
		//sort iSet
		Set<Integer> sortedSet = new TreeSet<>(iSet);
		System.out.println(sortedSet);
		
		//sort iset with reverse order
		Set<Integer> sortedSet1 = new TreeSet<>(Collections.reverseOrder());
		sortedSet1.addAll(iSet);
		System.out.println(sortedSet1);
		
	} 
	
	public static void hashSetDemo1() {
		boolean b;
		Set<Integer> iSet = new HashSet<Integer>();
		b=iSet.add(10);
		System.out.println(b);
		
		iSet.add(5);
		b=iSet.add(5);
		System.out.println(b);
		
		iSet.add(8);
		iSet.add(101);
		iSet.add(50);
		iSet.add(80);
		iSet.add(80);
		System.out.println(iSet);
		
		Set<Employee> eSet = new HashSet<>();
		
		Employee emp1 = new Employee(1, "Abhi", 1000);
		Employee emp2 = new Employee(5, "Sam", 8000);
		Employee emp3 = new Employee(4, "Jessica", 5000);
		Employee emp4 = new Employee(2, "Rose", 2000);
		Employee emp5 = new Employee(3, "Ajay", 10000);
		Employee emp6 = new Employee(5, "Sam", 8000);
		
		System.out.println("emp2.equals(emp6)="+emp2.equals(emp6));
		System.out.println(emp2.hashCode());
		System.out.println(emp6.hashCode());
		
		eSet.add(emp1);
		eSet.add(emp2);
		eSet.add(emp3);
		eSet.add(emp4);
		eSet.add(emp5);
		eSet.add(emp5);
		eSet.add(emp6);
		
		display(eSet);
		b= eSet.contains(new Employee(5, "Sam", 8000));
		System.out.println(b);
	}
	
	public static void iterateSet(Set<?> set) {
		Iterator<?> iterator = set.iterator();
        
	}
	
	public static void display(Set<?> set) {
		for(Object o:set) {
			System.out.println(o);
		}
		System.out.println();
	}
	
	public static void arrayListDemo1() {
		Employee emp1 = new Employee(1, "Abhi", 1000);
		Employee emp2 = new Employee(5, "Sam", 8000);
		Employee emp3 = new Employee(4, "Jessica", 5000);
		Employee emp4 = new Employee(2, "Rose", 2000);
		Employee emp5 = new Employee(3, "Ajay", 10000);
		
		List<Employee> empList = new ArrayList<Employee>();
		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		empList.add(emp5);
		empList.add(emp5);
		
		
		display(empList);
		Collections.sort(empList);
		System.out.println("Sort by default order i.e Id");
		display(empList);
		
		System.out.println("\nSort by salary");
		Collections.sort(empList, new SalaryComparator());
		display(empList);
		
		System.out.println("\nSort by name");
		Collections.sort(empList,new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
		display(empList);
		
	}
	
	
	public static void arrayListDemo() {
		List<Integer> iList = new ArrayList<Integer>(20);
		iList.add(10);
		iList.add(5);
		iList.add(8);
		iList.add(101);
		iList.add(50);
		iList.add(80);
		
		System.out.println(iList);
		Collections.sort(iList);
		System.out.println(iList);
		Collections.sort(iList, Collections.reverseOrder());
		System.out.println(iList);
		Collections.sort(iList, new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				return (String.valueOf(o1)).compareTo(o2+"");
			}
		});
		System.out.println(iList); 
		
		iterateList(iList);
		
		
	}
	
	public static void iterateList(List<Integer> list) {
		//enhanced for loop
		System.out.println("Iteration via enhanced for loop");
		for(Integer i :list) {
			System.out.println(i);
			if(i == 5) {
				list.remove(i);
			}
		}
		System.out.println("----------------");
		
		
		
	}
	
	public static void iterateList1(List<Integer> list) {
		Iterator<Integer> itr = list.iterator();
		while(itr.hasNext()) {
			Integer iob = itr.next();
			if(iob == 5) {
				itr.remove();
			}
		}
	}
	
	public static void iterateList2(List<Integer> list) {
		ListIterator<Integer> itr = list.listIterator();
		
	}

	public static void genericDemo1() {
		List<Integer> iList = new ArrayList<Integer>();
		iList.add(10);
		iList.add(5);
		iList.add(8);

		List<Double> dList = new ArrayList<Double>();
		dList.add(1.2);
		dList.add(7.2);
		dList.add(11.2);
		dList.add(1.26);

		display(iList);
		display(dList);
		
		List<String> sList =new ArrayList<String>();
		sList.add("Apple");
		sList.add("Mango");
		sList.add("Orange");
		sList.add("Grapes");
		display(sList);
		
		System.out.println("Average of int list: "+calculateAverage(iList));
		System.out.println("Average of double list: "+calculateAverage(dList));
		//System.out.println("Average of double list: "+calculateAverage(sList));
	}

	public static void display(List<?> list) {
		//list.add(new Employee());
		for(Object i:list) {
			System.out.println(i);
		}
		System.out.println("-----------------------------------");
	}
	
	public static double calculateAverage(List<? extends Number> list) {
		double total =0;
		for(Number i:list) {
			total = total +i.doubleValue();
		}
		return total/list.size();
	}

	
	public static void genericDemo() {
		Generic<Integer> iob = new Generic<Integer>(10);
		Integer i = iob.getInstance();
		// iob.setInstance("abcd");
		System.out.println(i);

		Generic<String> sob = new Generic<String>("Happy Holi");
		String str = sob.getInstance();
		System.out.println(str);

		// iob = sob;

		Generic g = new Generic("Apple");

	}

	public static void generalDemo() {
		General intInstance = new General(10);
		Integer i = (Integer) intInstance.getInstance();
		System.out.println(i);
		// intInstance.setInstance("Abde");

		General stringInstance = new General("Happy Holi");
		String str = (String) stringInstance.getInstance();
		System.out.println(str);

		intInstance = stringInstance;
		i = (Integer) intInstance.getInstance();
		System.out.println(i);

	}

}
