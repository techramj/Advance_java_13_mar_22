package com.zensar;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account2 {
	
	private int accountId;
	private AtomicInteger balance;
	
	
	
	public Account2() {
		// TODO Auto-generated constructor stub
	}

	public Account2(int accountId, int balance) {
		super();
		this.accountId = accountId;
		this.balance =  new AtomicInteger(balance);
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	
	
	public  void deposit(int amount) {
	;
		System.out.println("Balance is :"+balance);
		System.out.println("deposting amount: "+amount);
		balance.addAndGet(amount);
		System.out.println("Deposited successfully");
		System.out.println("Current balance: "+balance);
		System.out.println();
		
	}
	
	public void withdraw(int amount) {
		System.out.println(Thread.currentThread().getName());
		System.out.println("Balance is :"+balance);
		System.out.println("withdrawing amount: "+amount);
		balance.addAndGet(-amount);
		System.out.println("Withdrawn successfully");
		System.out.println("Current balance: "+balance);
		System.out.println();
		deposit(100);
	}
	

}
