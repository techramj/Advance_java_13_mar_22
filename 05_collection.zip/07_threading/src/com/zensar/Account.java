package com.zensar;

public class Account {
	
	private int accountId;
	private Integer balance;
	
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(int accountId, int balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public synchronized void deposit(int amount) {
		System.out.println("Balance is :"+balance);
		System.out.println("deposting amount: "+amount);
		balance = balance +amount;
		System.out.println("Deposited successfully");
		System.out.println("Current balance: "+balance);
		System.out.println();
	}
	
	public synchronized void withdraw(int amount) {
		System.out.println(Thread.currentThread().getName());
		System.out.println("Balance is :"+balance);
		System.out.println("withdrawing amount: "+amount);
		balance = balance - amount;
		System.out.println("Withdrawn successfully");
		System.out.println("Current balance: "+balance);
		System.out.println();
		deposit(100);
	}
	
	
	public  void withdraw1(int amount) {
		synchronized (this) {
			System.out.println(Thread.currentThread().getName());
			System.out.println("Balance is :"+balance);
			System.out.println("withdrawing amount: "+amount);
			balance = balance - amount;
			System.out.println("Withdrawn successfully");
			System.out.println("Current balance: "+balance);
			System.out.println();
		}
	}

}
