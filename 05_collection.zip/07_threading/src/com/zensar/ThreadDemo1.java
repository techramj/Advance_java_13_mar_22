package com.zensar;

public class ThreadDemo1 {
	public static void main(String[] args) {
		runnableExp2();
	}
	
	public static void runnableExp2() {
		Runnable r1 = new MyRunnable();
		
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r1);
		t1.start();
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("End");
	}

	
	public static void runnableExp1() {
		Runnable r1 = new MyRunnable();
		Runnable r2 = new MyRunnable();
		
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r2);
		t1.start();
		t2.start();
		System.out.println("End");
	}

	public static void exp2() {
		MyThread ob = new MyThread();

		Thread t1 = new Thread(ob);
		Thread t2 = new Thread(ob);

		t1.setPriority(Thread.MAX_PRIORITY);

		t1.start();
		t2.start();
	}

	public static void exp1() {
		Thread t1 = new MyThread();
		Thread t2 = new MyThread();

		t1.setPriority(Thread.MAX_PRIORITY);

		t1.start();
		t2.start();
	}
	
	public static void exp0() {
		
		Thread t1 = new MyThread();
		Thread t2 = new MyThread();

		t1.setPriority(Thread.MAX_PRIORITY);
		long x =System.currentTimeMillis();
		t1.run();
		t2.run();
		long y = System.currentTimeMillis();
		System.out.println((y-x)/1000);
	}
}
