package com.zensar;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Account3 {
	
	private int accountId;
	private Integer balance;
	Lock lock = new ReentrantLock();
	
	
	public Account3() {
		// TODO Auto-generated constructor stub
	}

	public Account3(int accountId, int balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public  void deposit(int amount) {
		lock.lock();
		System.out.println("Balance is :"+balance);
		System.out.println("deposting amount: "+amount);
		balance = balance +amount;
		System.out.println("Deposited successfully");
		System.out.println("Current balance: "+balance);
		System.out.println();
		lock.unlock();
	}
	
	public void withdraw(int amount) {
		lock.lock();
		System.out.println(Thread.currentThread().getName());
		System.out.println("Balance is :"+balance);
		System.out.println("withdrawing amount: "+amount);
		balance = balance - amount;
		System.out.println("Withdrawn successfully");
		System.out.println("Current balance: "+balance);
		System.out.println();
		deposit(100);
		lock.unlock();
	}
	

}
