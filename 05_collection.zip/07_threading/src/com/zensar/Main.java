package com.zensar;

public class Main {
	public static void main(String[] args) {
		Account account1 = new Account(1,20000);
		Account account2 = new Account(2,20000);
		
		Bank bank1 = new Bank(account1);
		Bank bank2 = new Bank(account2);
		
		Thread t1 = new Thread(bank1);
		t1.setName("user1");
		
		Thread t2 = new Thread(bank2);
		t2.setName("user2");
		
		t1.start();
		t2.start();
	}
}
